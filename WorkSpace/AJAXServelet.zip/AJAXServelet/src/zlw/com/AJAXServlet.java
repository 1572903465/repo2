package zlw.com;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
@WebServlet("/AJAXServlet")
public class AJAXServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String sname = new String(request.getParameter("a").getBytes("ios-8859-1"), "utf-8");
        String sPid = new String(request.getParameter("b").getBytes("ios-8859-1"), "utf-8");

        response.setHeader("Content-type","text/html;charset=utf-8");

        response.getWriter().write("后台接收到AJAX请求后处理完成返回相应信息"+"post"+sname + "----" + sPid);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String sname = request.getParameter("name");
        String sPid = request.getParameter("pid");
        response.setHeader("Content-type","text/html;charset=utf-8");
        response.getWriter().write("GET"+sname + "----" + sPid);
    }
}
