package com.neusoft.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.neusoft.model.Student;

public class TestSystemImpl extends TestSystem {
	//students--hashmap

	@Override
	public void inputScore(Student stud) {
		// TODO Auto-generated method stub
		this.students.put(stud.getName(), stud);

	}
// py  lxd   lmy
	@Override
	public Student findStudentByProperty(String propertyName, Serializable p) {
		//  Name   Subject   Score
		//  ����  Map(keySet k->values  v)
		for(Student  stu : students.values()) {			
			 switch (propertyName) {
			case "name":
				if(stu.getName().equals(p.toString()))
					return stu;
				break;
			case "subject":
				if(stu.getSubject().equals(p.toString()))
					return stu;
				break;
			case "score":
				if((stu.getScore()+"").equals(p.toString()))
					return stu;
				break;
			default:
				break;
			}
		}
		
		
		return null;
	}

	@Override
	public List<Student> getStudents() {
		return new ArrayList(students.values());
	}

	@Override
	public void sortStudentByScore() {
		 //  map.values->stu.score-sort
	  List<Student> list=new ArrayList(students.values());
	  Collections.sort(list, 
    new Comparator<Student>() {

		@Override
		public int compare(Student s1, Student s2) {
			if(s1.getScore()>s2.getScore())
				return 1;
			else if(s1.getScore()==s2.getScore())
				return 0;
			else return -1;
		}
	});
	  
	  for(Student stud: list) {
		System.out.println(stud.getName()+" subject:"
	  +stud.getSubject()+" score:"+stud.getScore());
		
	  }
		

	}

	public void myfun1(MyInterface my) {
		
	}
	public void myfun2() {
		MyClass my=null;
		myfun1(my);
		myfun1(new MyInterface() {

			@Override
			public void show() {
				System.out.println("hello");				
			}
		});
	}
}


interface  MyInterface{
	void show();
}

class MyClass implements MyInterface{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}




