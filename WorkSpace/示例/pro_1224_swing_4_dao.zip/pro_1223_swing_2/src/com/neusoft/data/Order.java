package com.neusoft.data;

import java.util.ArrayList;
import java.util.List;

public class Order {
	public String Order_id;
	public String order_time;
	public String order_name;
	public String order_phone;
	public boolean order_isPay=false;
	
	public List<Dish> order_dishs=new ArrayList<>();
	 
	public Float  getTotal() {
		float fee=0;
		for(Dish d:order_dishs) {
			fee+=d.getDishNum()*d.getDishPrice();
		}
		return fee;
	}

}
