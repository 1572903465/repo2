package com.neusoft.view;

import javax.swing.JPanel;
import javax.swing.text.View;

import com.neusoft.data.FoodOrderData;
import com.neusoft.data.Order;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.awt.event.ActionEvent;

public class FoodList extends JPanel {
	public FoodList() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(24, 10, 174, 104);
		add(panel);
		panel.setLayout(null);
		
		JLabel lbl_1 = new JLabel("New label");
		lbl_1.setBounds(0, 0, 132, 70);
		panel.add(lbl_1);
		lbl_1.setIcon(new ImageIcon("image/1.jpg"));
	
		JCheckBox chb_1 = new JCheckBox("������Ѽ");
		chb_1.setBounds(0, 75, 103, 23);
		panel.add(chb_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(24, 124, 174, 104);
		add(panel_1);
		
		JLabel lbl_2 = new JLabel("New label");
		lbl_2.setBounds(0, 0, 132, 70);
		lbl_2.setIcon(new ImageIcon("image/3.jpg"));
		panel_1.add(lbl_2);
		
		JCheckBox chb_2 = new JCheckBox("\u849C\u6CE5\u767D\u8089");
		chb_2.setBounds(0, 75, 103, 23);
		panel_1.add(chb_2);
		
		JButton btnNewOrder = new JButton("\u751F\u6210\u8BA2\u5355");
		btnNewOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//1.�������棬->
				//2.List<Food> foods;
				//3.Service.save(foods)
				String dishName=null;
				
				Component[]  componets=FoodList.this.getComponents();
				for(Component c:componets) {
					if(c instanceof JPanel) {
						try {
							JCheckBox  cb=
									(JCheckBox) 
									((JPanel) c)
									.getComponent(1);
							if(cb!=null &&cb.isSelected()) {
								dishName=cb.getText();
							}
						} catch (Exception e) {
							
						}
					}
				}
				int num=0;
				float price=.0f;
				
				String input=JOptionPane
						.showInputDialog(null,"�������������,�绰����");
				String[] inputs=input.split(",");
				
				String name=inputs[0];
				String phone=inputs[1];
				
				Order  order=new Order(dishName,num,price);
				FoodOrderData.setOrder(order);
				ViewComm.showMessage(input+" "+dishName);
				
				
			}
		});
		btnNewOrder.setBounds(165, 250, 81, 23);
		add(btnNewOrder);
	}
}
