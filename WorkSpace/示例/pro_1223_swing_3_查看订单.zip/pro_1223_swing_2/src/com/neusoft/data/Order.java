package com.neusoft.data;

public class Order {
	private int dishNO;	
	private String dishName;
	private int  dishNum;
	private Float dishPrice;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Order(String dishName, int dishNum, Float dishPrice) {
		super();
		this.dishName = dishName;
		this.dishNum = dishNum;
		this.dishPrice = dishPrice;
	}
	
	public int getDishNO() {
		return dishNO;
	}



	public void setDishNO(int dishNO) {
		this.dishNO = dishNO;
	}
	
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public Float getDishPrice() {
		return dishPrice;
	}
	public void setDishPrice(Float dishPrice) {
		this.dishPrice = dishPrice;
	}
	public int getDishNum() {
		return dishNum;
	}
	public void setDishNum(int dishNum) {
		this.dishNum = dishNum;
	}

	

}
