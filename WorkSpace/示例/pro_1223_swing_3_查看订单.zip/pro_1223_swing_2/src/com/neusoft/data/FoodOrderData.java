package com.neusoft.data;

import java.util.HashMap;
import java.util.Map;

//Food   FoodManager->
public class FoodOrderData {
	private static Map<Integer,Order> orders=
			new HashMap<>();
	
	public static void setOrder(Order order) {
		
		orders.put(order.getDishNO(), order);
	}
	public static Order getOrder(int no) {
		return null;
	}

}
