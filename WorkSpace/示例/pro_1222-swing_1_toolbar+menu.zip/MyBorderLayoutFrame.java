package edu.scnu.swing.test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JToolBar;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;

public class MyBorderLayoutFrame implements ActionListener{
	
	public MyBorderLayoutFrame(){
	     JFrame f=new JFrame();
	        Container contentPane=f.getContentPane();
	        f.getContentPane().setLayout(null);
	        
	        JMenuBar menuBar = new JMenuBar();
	        menuBar.setFont(new Font("΢���ź�", Font.PLAIN, 8));
	        menuBar.setBounds(0, 0, 284, 24);
	        f.getContentPane().add(menuBar);
	        
	        JMenu mnNewMenu = new JMenu("ϵͳ");
	        menuBar.add(mnNewMenu);
	        
	        JMenuItem mntmNewMenuItem = new JMenuItem("��͹���");
	        mntmNewMenuItem.setFont(new Font("΢���ź�", Font.PLAIN, 10));
	        mntmNewMenuItem.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent ae) {
					 showMessage("��͹���");					
				}
			});
	        mnNewMenu.add(mntmNewMenuItem);
	        
	        
	        JMenuItem mntmNewMenuItem_1 = new JMenuItem("\u7528\u6237\u7BA1\u7406");
	        mnNewMenu.add(mntmNewMenuItem_1);
	        mntmNewMenuItem_1.setHorizontalAlignment(SwingConstants.CENTER);
	        
	        JMenuItem mntmNewMenuItem_2 = new JMenuItem("\u8BA2\u5355\u7BA1\u7406");
	        mnNewMenu.add(mntmNewMenuItem_2);
	        
	        JMenu mnNewMenu_1 = new JMenu("\u767B\u5F55");
	        menuBar.add(mnNewMenu_1);
	        
	        JMenu mnNewMenu_2 = new JMenu("\u9000\u51FA");
	        menuBar.add(mnNewMenu_2);
	        
	        JToolBar toolBar = new JToolBar();
	        toolBar.setBounds(0, 25, 284, 24);
	        f.getContentPane().add(toolBar);
	        
	        JButton btnPay = new JButton("\u7ED3\u8D26");
	        btnPay.addActionListener(this);
	        toolBar.add(btnPay);
	        //Action
	        JButton btnOrder = new JButton("\u70B9\u9910");
	        btnOrder.addActionListener(this);
	        toolBar.add(btnOrder);
	        
	        JPanel panel = new JPanel();
	        panel.setBounds(0, 59, 274, 273);
	        f.getContentPane().add(panel);
	        panel.setLayout(new BorderLayout(0, 0));
	        JButton button = new JButton("����");
	        panel.add(button, BorderLayout.NORTH);
	        JButton button_1 = new JButton("WEST");
	        panel.add(button_1, BorderLayout.NORTH);
	        JButton button_2 = new JButton("SOUTH");
	        panel.add(button_2, BorderLayout.NORTH);
	        JButton button_3 = new JButton("NORTH");
	        panel.add(button_3, BorderLayout.NORTH);
	        JLabel label = new JLabel("CENTER",JLabel.CENTER);
	        panel.add(label, BorderLayout.NORTH);
	        f.setTitle("BorderLayout");
	        
	        Dimension screen=Toolkit.getDefaultToolkit()
	        		.getScreenSize();
	        int width=400,height=350;
	        f.setBounds(((int)screen.getWidth()-width)/2, 
	        		((int)screen.getHeight()-height)/2, 
	        		width, height);
	        f.setVisible(true);
	        /***read**/
	        /*�����رմ��ڵĲ���������ûд��һ�Σ��������Ѿ��رմ����ˣ������򲢲�����ֹ��
	         */
	        f.addWindowListener(
	           new WindowAdapter(){
	               public void windowClosing(WindowEvent e){
	                  System.exit(0);	
	               }	
	           }	
	        );
	       /***read**/
	   }	
	   public static void main(String[] args){
		   MyBorderLayoutFrame b=new MyBorderLayoutFrame();	
	   }
	@Override
	public void actionPerformed(ActionEvent et) {		 
		JButton btn= (JButton) et.getSource(); 
//		String file="C:\\Users\\Public\\Pictures\\Sample Pictures\\yjx.jpg";
//		JOptionPane.showMessageDialog(null, 
//				"������ʾ��Ϣ",
//					"����", 
//					JOptionPane.WARNING_MESSAGE 
//					);
		if(btn.getText().equals("���")) {
			JOptionPane.showMessageDialog(null,"order...");
		}
		else {
			JOptionPane.showMessageDialog(null,"pay...");
		}		
	}
	
	void showMessage(String msg) {
		JOptionPane.showMessageDialog(null,msg);
	}
}



 









