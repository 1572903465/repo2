package com.neusoft.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class OrderSystemManager {

	private JFrame frame;
	JPanel panel_content = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrderSystemManager window = new OrderSystemManager();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OrderSystemManager() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("���ϵͳ");
		frame.setSize(458, 443);
		ViewComm.setLocation(frame);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JMenuBar menubar_main = new JMenuBar();
		menubar_main.setBounds(0, 0, 450, 21);
		frame.getContentPane().add(menubar_main);
		
		JMenu menu_order = new JMenu("\u70B9\u9910\u7BA1\u7406");
		menubar_main.add(menu_order);
		
		JMenuItem order = new JMenuItem("\u70B9\u9910");
		menu_order.add(order);
		
		JToolBar toolbar_main = new JToolBar();
		toolbar_main.setBounds(0, 22, 450, 20);
		frame.getContentPane().add(toolbar_main);
		
		JButton btnOrder = new JButton("\u70B9\u9910");
		btnOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			JPanel p1=OrderSystemManager.this.panel_content;
			p1.removeAll();
			p1.repaint();
			FoodList foodList=new FoodList();
			foodList.setBounds(0, 0, 450, 300);
			p1.add(foodList);
			
			}
		});
		toolbar_main.add(btnOrder);
		
		JButton btnViewOrder = new JButton("\u67E5\u770B\u8BA2\u5355");
		toolbar_main.add(btnViewOrder);
		
		
		panel_content.setBounds(0, 42, 450, 370);
		frame.getContentPane().add(panel_content);
		
		JLabel lblImage = new JLabel("New label");
		panel_content.add(lblImage);
		 
		lblImage.setIcon(new ImageIcon("C:\\Users\\Public\\Pictures\\Sample Pictures\\Koala.jpg"));
	}
}
