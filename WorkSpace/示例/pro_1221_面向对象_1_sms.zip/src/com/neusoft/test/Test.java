package com.neusoft.test;

public class Test {
//ctrl+/     alt+/
//����    
//	Java 100 MySQL 95 Swing 85
	
      // hello world
	public static  void main(String[] x) {
		 System.out.print("hi  ");
	 
	 }
	
}
