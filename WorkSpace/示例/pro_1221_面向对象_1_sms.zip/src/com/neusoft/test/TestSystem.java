package com.neusoft.test;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import com.neusoft.model.Student;

//1.input 2.save  3.do  4.output
public abstract class TestSystem {
	private static HashMap<String, Student> 
	students = new HashMap(); 
	//set
	abstract public void inputScore(Student stud);
	//sys op   findStudentBy id,name,SNO,
	public abstract Student 
	findStudentByProperty(
			String propertyName,Serializable p);
	public abstract List<Student> getStudents();
	public abstract void sortStudentByScore();
}
