package com.neusoft.view;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ViewComm {
	
	public static void setLocation(JFrame  frame) {
		int width=frame.getWidth(),
				height=frame.getHeight();
		Dimension  d=Toolkit.getDefaultToolkit().getScreenSize();
        int swidth=d.width;
		int sheight=d.height;
		frame.setBounds(
				(swidth-width)/2, 
                 (sheight-height)/2, width, height);
		
	}

//	public static Componet
	public static void showMessage(String msg) {
		JOptionPane.showMessageDialog(null, msg);
	}
	
	public static String createOrderNO() {
		Date  d=new Date();
		String ordNO=d.toLocaleString();
		//2019-12-24 13:40:11
		String NO= ordNO
				.replaceAll(" ", "")
				.replace("-", "")
				.replace(":", "");
		return NO;
	}
	
}
