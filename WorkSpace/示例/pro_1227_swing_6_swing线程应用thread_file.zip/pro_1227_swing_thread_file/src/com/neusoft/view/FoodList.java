package com.neusoft.view;

import javax.swing.JPanel;
import javax.swing.text.View;

import com.neusoft.data.Dish;
import com.neusoft.data.FoodOrderData;
import com.neusoft.data.Order;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.awt.Component;
import java.awt.event.ActionEvent;

public class FoodList extends JPanel {
	
	
	
	public FoodList() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(24, 10, 174, 104);
		add(panel);
		panel.setLayout(null);
		
		JLabel lbl_1 = new JLabel("New label");
		lbl_1.setBounds(0, 0, 132, 70);
		panel.add(lbl_1);
		lbl_1.setIcon(new ImageIcon("image/1.jpg"));
	
		JCheckBox chb_1 = new JCheckBox("������Ѽ");
		chb_1.setBounds(0, 75, 103, 23);
		panel.add(chb_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(24, 124, 174, 104);
		add(panel_1);
		
		JLabel lbl_2 = new JLabel("New label");
		lbl_2.setBounds(0, 0, 132, 70);
		lbl_2.setIcon(new ImageIcon("image/3.jpg"));
		panel_1.add(lbl_2);
		
		JCheckBox chb_2 = new JCheckBox("\u849C\u6CE5\u767D\u8089");
		chb_2.setBounds(0, 75, 103, 23);
		panel_1.add(chb_2);
		
		JButton btnNewOrder = new JButton("\u751F\u6210\u8BA2\u5355");
		btnNewOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//1.�������棬->
				//2.List<Food> foods;
				//3.Service.save(foods)
				List<Dish> dishs=
						new ArrayList<>();
				
				String dishName=null;
				
				Component[]  componets=FoodList.this.getComponents();
				for(Component c:componets) {
					if(c instanceof JPanel) {
						try {
							JCheckBox  cb=
									(JCheckBox) 
									((JPanel) c)
									.getComponent(1);
							if(cb!=null &&cb.isSelected()) {
								dishName=cb.getText();
								int num=1;
								float price=.0f;							
								Dish  d1=new Dish(dishName,num,price);								 
								dishs.add(d1);
							}
						} catch (Exception e) {
							
						}
					}
				}
				
//				ViewComm.showMessage(input+" "+dishName);
				 
				//���涩����Ϣ
					String input=JOptionPane
							.showInputDialog(null,"�������������,�绰����");
					String[] inputs=input.split(",");
					
					String name=inputs[0];
					String phone=inputs[1];
					
					Order order=new Order();
 
					order.order_name=name;
					order.order_phone=phone;
					order.order_time=new Date().toLocaleString();
					order.Order_id=ViewComm.createOrderNO();
					order.order_dishs=dishs;
				 
					FoodOrderData.setOrder(order);					
					ViewComm.showMessage(" �����ɶ��� ");
				 
				
				
			}
		});
		btnNewOrder.setBounds(24, 251, 81, 23);
		add(btnNewOrder);
		
		JButton btnPay = new JButton("\u5B8C\u6210\u4E0B\u5355");
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//orders-->map  -->db
				//1. ����-�����Ҷ���
				//2. ���� �������ݿ�    
				String no="123";
				Order order=FoodOrderData.getOrder(no);
				order.order_isPay=true;
				String log=" no:"+no+" order_name"+order.order_name;
				//sql=insert into orders()
				// values(order_id,order_name,order_phone,order_time,'1,2')
				Thread t=new Thread(new MyLog("c:/1.log",log));
				t.start();
				//����������Ҫʹ��Swingworker���߳�
				//ʵ�ֺ�̨�߼������ˢ�½���
				
			}
		});
		btnPay.setBounds(128, 251, 93, 23);
		add(btnPay);

		JButton btnNewButton = new JButton("done  more time");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				


				
				
			}
		});
		btnNewButton.setBounds(24, 284, 81, 23);
		add(btnNewButton);
	}
}

class MyLog implements Runnable{
    File  file;
    String  log;
    public MyLog(String filename,String log){
    	file=new File(filename);
    	this.log=log;
    }
	@Override
	public void run() {
		BufferedWriter  bw;
		try {
			bw=new BufferedWriter(new FileWriter(file));
			bw.write(log);
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
}



