package com.neusoft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.neuedu.utils.JdbcUtil;
import com.neusoft.data.Order;

public class OrdersDAO {
	final String SELECT_ORDER_BY_NO=
			"select  order_user,order_no,order_phoneno from orders where  order_no=?";
	final String SELECT_ALL_ORDER="select order_no,order_user,order_phoneno from orders";
	
	
	//select
	public List<Order> getOrders(){
		return null;
	}
	
	public  Order  get(String orderNO){
		
		try {
			JdbcUtil.getConnection();
			ResultSet rs=JdbcUtil.executeQuery(
					SELECT_ORDER_BY_NO, orderNO);
			
			if(rs.next()) {
				Order order=new Order();
				order.Order_id=rs.getString(2);
				order.order_name=rs.getString(1);
				order.order_phone=rs.getString(3);
				return  order;
			}
			
			
			JdbcUtil.close();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
