package com.neusoft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.swing.JOptionPane;

import com.neusoft.data.Order;
 

public class Test {

	public static void main(String[] args) throws Exception {
		String orderNO=
				JOptionPane.showInputDialog("input your order NO");
		OrdersDAO  odao=new OrdersDAO();
		Order order=odao.get(orderNO);
		JOptionPane.showMessageDialog(
				null, order.Order_id+":"+order.order_name);
		
//		 final String url="jdbc:mysql://localhost:3306/orders?serverTimezone=GMT&&8";
//		 final String user="root";
//		 final String password="123456";
//			//jdbc   
//		//1.Connection
//		//2.Statement
//		//3.ResultSet
//		
//		String sql="insert into orders(order_no,order_user,order_phoneno) " + 
//				"values('20191224131321','zhao','123245778')";
//		String name="xiaowang";
//		String sql_update="update orders set order_user='"+name+"'  " + 
//				"where order_no='20191224131316';";
//		
//        new com.mysql.jdbc.Driver();
//        Connection conn=DriverManager
//        		.getConnection(url, user, password);		
////		System.out.println(conn);
//        Statement  stmt=conn.createStatement();
////        stmt.execute(sql_update);       
//        
//        
//        final String SELECT_ORDER_BY_NO="select order_no,order_user,order_phoneno " + 
//        		"from orders;";
//        ResultSet  rs=stmt.executeQuery(SELECT_ORDER_BY_NO);
//        while(rs.next())
//		{
//		String no=rs.getString(1);
//		String username=rs.getString(2);
//		String phone=rs.getString(3);
//		System.out.println(no+":"+username+":"+phone);
//		}      
        
        
        System.out.println("select end....");
        
	}

}
