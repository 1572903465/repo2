package com.neusoft.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Food   FoodManager->
public class FoodOrderData {
	private static Map<String,Order> orders=
			new HashMap<>();
	
	public static void setOrder(Order order) {
		
		orders.put(order.Order_id, order);
	}
	public static List<Order>  get(){
		return new ArrayList(orders.values());
		
	}
	
	public static Order getOrder(String no) {
		
		return orders.get(no);
	}

}
